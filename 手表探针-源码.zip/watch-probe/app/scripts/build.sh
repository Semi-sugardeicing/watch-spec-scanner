#!/bin/sh
# ─────────────────────────────────────────────────────────────────────
# 手表探针 · 无 Gradle 构建脚本
#   javac → d8 → APKEditor(打包资源) → apksigner
#
# 依赖：
#   · JDK 8+                 (javac / keytool)
#   · Android build-tools    (d8 / apksigner)
#   · 任意一个 platform 的 android.jar
#   · APKEditor.jar          https://github.com/REAndroid/APKEditor/releases
#
# 所有路径都能用环境变量覆盖：
#   BUILD_TOOLS  ANDROID_JAR  APKEDITOR_JAR  KEYSTORE  KS_PASS  KS_ALIAS
#
# 用法：
#   sh app/scripts/build.sh [输出.apk]
#   默认输出 <repo>/dist/watch-probe.apk
# ─────────────────────────────────────────────────────────────────────
set -e

HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=$(cd "$HERE/.." && pwd)
OUT=${1:-$ROOT/../dist/watch-probe.apk}

SDK=${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}}
: "${BUILD_TOOLS:=$SDK/build-tools/34.0.0}"
: "${ANDROID_JAR:=$SDK/platforms/android-34/android.jar}"
: "${APKEDITOR_JAR:=$HERE/APKEditor.jar}"
: "${KEYSTORE:=$ROOT/watch-probe.jks}"
: "${KS_PASS:=watchprobe}"
: "${KS_ALIAS:=watchprobe}"

for f in "$BUILD_TOOLS/d8" "$BUILD_TOOLS/apksigner" "$ANDROID_JAR" "$APKEDITOR_JAR"; do
    if [ ! -e "$f" ]; then
        echo "缺少依赖：$f"
        echo "  用 BUILD_TOOLS / ANDROID_JAR / APKEDITOR_JAR 指定路径"
        echo "  APKEditor.jar 下载：https://github.com/REAndroid/APKEditor/releases"
        exit 1
    fi
done

W=$ROOT/build
rm -rf "$W"
mkdir -p "$W/classes" "$W/dex" "$W/pack"

echo "[1/5] javac"
find "$ROOT/src" -name '*.java' > "$W/srcs.txt"
javac -encoding UTF-8 -nowarn -source 8 -target 8 \
    -bootclasspath "$ANDROID_JAR" -cp "$ANDROID_JAR" \
    -d "$W/classes" @"$W/srcs.txt"

echo "[2/5] d8  (min-api 23，兼容到 Android 6.0 的老手表)"
find "$W/classes" -name '*.class' > "$W/classes.txt"
"$BUILD_TOOLS/d8" --lib "$ANDROID_JAR" --min-api 23 --output "$W/dex" @"$W/classes.txt"

echo "[3/5] 套模板 + 打包"
cp -r "$ROOT/template/." "$W/pack/"
cp "$W/dex/classes.dex" "$W/pack/root/classes.dex"
java -jar "$APKEDITOR_JAR" b -i "$W/pack" -o "$W/unsigned.apk" > "$W/pack.log" 2>&1 || {
    echo "APKEditor 打包失败，日志尾部："; tail -20 "$W/pack.log"; exit 1; }

echo "[4/5] 签名"
if [ ! -f "$KEYSTORE" ]; then
    echo "  未找到密钥，自动生成自签名密钥：$KEYSTORE"
    keytool -genkeypair -keystore "$KEYSTORE" -alias "$KS_ALIAS" \
        -keyalg RSA -keysize 2048 -validity 10000 \
        -storepass "$KS_PASS" -keypass "$KS_PASS" \
        -dname "CN=Watch Probe, OU=Dev, O=WatchProbe, C=CN" >/dev/null 2>&1
fi
mkdir -p "$(dirname "$OUT")"
"$BUILD_TOOLS/apksigner" sign --ks "$KEYSTORE" --ks-pass "pass:$KS_PASS" \
    --key-pass "pass:$KS_PASS" --out "$W/signed.apk" "$W/unsigned.apk"
if [ -x "$BUILD_TOOLS/zipalign" ] && "$BUILD_TOOLS/zipalign" -f 4 "$W/signed.apk" "$OUT" 2>/dev/null; then
    :
else
    cp "$W/signed.apk" "$OUT"
    echo "  （zipalign 不可用，跳过对齐 —— 侧载无影响）"
fi
"$BUILD_TOOLS/apksigner" verify --print-certs "$OUT" | head -4

echo "[5/5] 完成 → $OUT"
echo "      大小 $(wc -c < "$OUT") 字节"
