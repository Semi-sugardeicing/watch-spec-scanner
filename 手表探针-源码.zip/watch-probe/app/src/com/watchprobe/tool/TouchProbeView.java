package com.watchprobe.tool;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

/**
 * 触摸测试区：单击 / 长按 / 双击 / 拖动 分别计数。
 * 自己吃掉手势事件（requestDisallowInterceptTouchEvent），否则拖动会被外层 ScrollView 抢走。
 */
public class TouchProbeView extends View {

    public interface Listener {
        void onTouchStat(String kind);
    }

    private final GestureDetector detector;
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Listener listener;
    private boolean dragging;

    public TouchProbeView(Context ctx) {
        super(ctx);
        float density = ctx.getResources().getDisplayMetrics().density;
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(1.5f * density);
        border.setColor(0xFF00E676);
        label.setColor(0xFF607D8B);
        label.setTextSize(9f * density);
        label.setTextAlign(Paint.Align.CENTER);
        setBackgroundColor(0xFF16222E);
        setClickable(true);

        detector = new GestureDetector(ctx, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }

            @Override public void onLongPress(MotionEvent e) { emit("长按"); }

            @Override public boolean onSingleTapConfirmed(MotionEvent e) { emit("单击"); return true; }

            @Override public boolean onDoubleTap(MotionEvent e) { emit("双击"); return true; }

            @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (!dragging) {
                    dragging = true;
                    emit("拖动");
                }
                return true;
            }
        });
    }

    public void setListener(Listener l) { this.listener = l; }

    private void emit(String kind) {
        if (listener != null) listener.onTouchStat(kind);
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragging = false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                break;
            default:
                break;
        }
        detector.onTouchEvent(ev);
        return true;
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float density = getResources().getDisplayMetrics().density;
        c.drawRect(border.getStrokeWidth() / 2f, border.getStrokeWidth() / 2f,
                getWidth() - border.getStrokeWidth() / 2f, getHeight() - border.getStrokeWidth() / 2f, border);
        float cyy = getHeight() / 2f - (label.descent() + label.ascent()) / 2f;
        c.drawText("触摸测试区  点 / 长按 / 双击 / 拖", getWidth() / 2f, cyy, label);
    }
}
