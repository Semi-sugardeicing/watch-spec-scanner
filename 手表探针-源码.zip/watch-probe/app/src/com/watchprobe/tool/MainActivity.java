package com.watchprobe.tool;

import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.DisplayCutout;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

/**
 * 手表探针 —— 通用版
 *
 * 一次性测清三件事：
 *   1. 屏幕：物理/可用尺寸、密度、dp、圆屏与否、系统栏与刘海内缩、按屏自动算出的安全边距
 *   2. 表冠：硬件枚举 + 实收 ACTION_SCROLL 计数（两者结论可能不一致，分开看）
 *   3. 触摸：单击/长按/双击/拖动 + 物理按键
 *
 * 不联网、不读存储、不申请任何权限；所有数值运行时读取，不写死任何机型。
 */
public class MainActivity extends Activity {

    private static final int BG     = 0xFF0E1620;
    private static final int FG     = 0xFFECEFF1;
    private static final int DIM    = 0xFF90A4AE;
    private static final int ACCENT = 0xFF00E676;
    private static final int WARN   = 0xFFFF5252;
    private static final int KEY    = 0xFFFFD54F;

    private float density = 2f;
    private boolean roundScreen = false;

    private TextView tvHeader, tvScreen, tvInsets, tvRotary, tvCrownCount, tvCrownDelta,
            tvCrownLast, tvScrollPos, tvTouch, tvLastKey, tvInputs;
    private TouchProbeView touch;
    private ScrollView scroll;
    private RulerView ruler;
    private View mainCol, rulerLayer;

    private int nClick, nLong, nDouble, nDrag;
    private int crownCount, scrollCount;
    private float crownDelta;
    private String crownLast = "（还没收到）";
    private String insetsText = "（等待系统回调）";
    private boolean hasRotaryDevice = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        density = getResources().getDisplayMetrics().density;
        roundScreen = getResources().getConfiguration().isScreenRound();

        // 全屏沉浸：铺满整块屏，但把系统栏内缩真值留给探针读
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        setContentView(buildUI());
        fillScreenInfo();
        probeInputDevices();
        updateCrown();
        updateTouch();
    }

    // ─────────────────────────── 界面 ───────────────────────────

    private View buildUI() {
        final FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        // 圆屏：四边留内接正方形的边距（= (边长 - 边长/√2)/2）；方屏：留 3.5%
        int minSide = Math.min(physicalSize()[0], physicalSize()[1]);
        int m = roundScreen
                ? Math.round((minSide - minSide / 1.41421356f) / 2f)
                : Math.round(minSide * 0.035f);
        col.setPadding(m, m, m, m);

        tvHeader = makeTv("", 11f, ACCENT, true);
        tvHeader.setGravity(Gravity.CENTER);
        col.addView(tvHeader);

        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(true);
        scroll.setFocusable(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content, new ViewGroup.LayoutParams(-1, -2));
        col.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        addTitle(content, "屏幕");
        tvScreen = addLine(content, "", 11f, FG);
        tvInsets = addLine(content, "", 11f, FG);

        addTitle(content, "表冠 / 旋转输入");
        tvRotary = addLine(content, "", 13f, FG, true);
        tvCrownCount = addLine(content, "", 11f, FG);
        tvCrownDelta = addLine(content, "", 11f, FG);
        tvCrownLast = addLine(content, "", 10f, DIM);
        tvScrollPos = addLine(content, "", 10f, DIM);
        addLine(content, "转表冠：上面两个数会变 = App 收得到；同时本页能上下滚 = 系统愿意派发。两者结论独立。",
                10f, KEY);

        addTitle(content, "触摸 / 按键");
        tvTouch = addLine(content, "", 11f, FG);
        touch = new TouchProbeView(this);
        touch.setListener(new TouchProbeView.Listener() {
            @Override public void onTouchStat(String kind) {
                if ("单击".equals(kind)) nClick++;
                else if ("长按".equals(kind)) nLong++;
                else if ("双击".equals(kind)) nDouble++;
                else if ("拖动".equals(kind)) nDrag++;
                updateTouch();
            }
        });
        content.addView(touch, new LinearLayout.LayoutParams(-1, dp(64)));
        tvLastKey = addLine(content, "最近按键：无", 10f, DIM);

        addTitle(content, "输入设备");
        tvInputs = addLine(content, "", 9f, DIM);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button btnRuler = makeBtn("标尺页");
        Button btnReset = makeBtn("重置计数");
        row.addView(btnRuler, new LinearLayout.LayoutParams(0, dp(34), 1f));
        row.addView(btnReset, new LinearLayout.LayoutParams(0, dp(34), 1f));
        col.addView(row, new LinearLayout.LayoutParams(-1, -2));

        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
        mainCol = col;

        // 标尺页（覆盖全屏）
        FrameLayout layer = new FrameLayout(this);
        ruler = new RulerView(this);
        ruler.setRoundScreen(roundScreen);
        layer.addView(ruler, new FrameLayout.LayoutParams(-1, -1));
        Button back = makeBtn("返回");
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(dp(76), dp(34));
        blp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        blp.bottomMargin = dp(14);
        layer.addView(back, blp);
        layer.setVisibility(View.GONE);
        root.addView(layer, new FrameLayout.LayoutParams(-1, -1));
        rulerLayer = layer;

        btnRuler.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showRuler(true); }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showRuler(false); }
        });
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                nClick = nLong = nDouble = nDrag = 0;
                crownCount = 0; crownDelta = 0f; scrollCount = 0;
                crownLast = "（已重置）";
                updateTouch();
                updateCrown();
                tvLastKey.setText("最近按键：无");
                tvScrollPos.setText("页面滚动位置 y=0");
            }
        });

        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                insetsText = describeInsets(insets);
                tvInsets.setText(insetsText);
                return insets;
            }
        });
        scroll.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View v, int sx, int sy, int osx, int osy) {
                tvScrollPos.setText("页面滚动位置 y=" + sy + "（能滚=系统放行表冠滚动）");
            }
        });
        scroll.requestFocus();
        return root;
    }

    private void showRuler(boolean show) {
        mainCol.setVisibility(show ? View.GONE : View.VISIBLE);
        rulerLayer.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) ruler.requestLayout();
    }

    private String describeInsets(WindowInsets insets) {
        int l = insets.getSystemWindowInsetLeft();
        int t = insets.getSystemWindowInsetTop();
        int r = insets.getSystemWindowInsetRight();
        int b = insets.getSystemWindowInsetBottom();
        StringBuilder sb = new StringBuilder();
        sb.append("systemBars 内缩  上").append(t).append(" 下").append(b)
                .append(" 左").append(l).append(" 右").append(r).append(" px");
        if (Build.VERSION.SDK_INT >= 28) {
            DisplayCutout cut = insets.getDisplayCutout();
            if (cut == null) {
                sb.append("\n刘海/挖孔：无");
            } else {
                Rect safe = new Rect(cut.getSafeInsetLeft(), cut.getSafeInsetTop(),
                        cut.getSafeInsetRight(), cut.getSafeInsetBottom());
                sb.append("\n刘海/挖孔：有  safeInset 上").append(safe.top).append(" 下").append(safe.bottom)
                        .append(" 左").append(safe.left).append(" 右").append(safe.right);
            }
        } else {
            sb.append("\n刘海/挖孔：API<28 无此接口");
        }
        return sb.toString();
    }

    // ─────────────────────── 数据采集 ───────────────────────

    private void fillScreenInfo() {
        int[] phys = physicalSize();
        int[] max = maxSize();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float wDp = phys[0] / density, hDp = phys[1] / density;
        int minSide = Math.min(phys[0], phys[1]);
        int marginPx = roundScreen
                ? Math.round((minSide - minSide / 1.41421356f) / 2f)
                : Math.round(minSide * 0.035f);

        tvHeader.setText(roundScreen ? "圆屏手表" : "方屏设备");
        tvHeader.setText(tvHeader.getText() + "  ·  " + Build.VERSION.RELEASE
                + "  (API " + Build.VERSION.SDK_INT + ")");

        tvScreen.setText(
                "物理屏幕  " + phys[0] + " × " + phys[1] + " px\n"
              + "应用可用  " + dm.widthPixels + " × " + dm.heightPixels + " px\n"
              + "最大窗口  " + max[0] + " × " + max[1] + " px\n"
              + "dp 尺寸   " + one(wDp) + " × " + one(hDp) + " dp\n"
              + "密度      " + dm.densityDpi + " dpi  (×" + two(density) + ")\n"
              + "圆屏      " + (roundScreen ? "YES (isScreenRound)" : "NO (isScreenRound)") + "\n"
              + "建议边距  " + (marginPx / density >= 1 ? Math.round(marginPx / density) + " dp" : "—")
                        + "  (安全方 " + Math.round(minSide / 1.41421356f / density) + " dp)\n"
              + "型号      " + Build.MANUFACTURER + " " + Build.MODEL + "\n"
              + "构建      " + Build.DISPLAY);

        tvInsets.setText(insetsText);
    }

    private void probeInputDevices() {
        StringBuilder sb = new StringBuilder();
        int[] ids = InputDevice.getDeviceIds();
        sb.append("共 ").append(ids.length).append(" 个输入设备\n");
        for (int id : ids) {
            InputDevice d = InputDevice.getDevice(id);
            if (d == null) continue;
            int src = d.getSources();
            boolean r = (src & InputDevice.SOURCE_ROTARY_ENCODER) != 0;
            if (r) hasRotaryDevice = true;
            sb.append("· ").append(d.getName())
              .append("  src=0x").append(Integer.toHexString(src))
              .append(r ? "  [ROTARY]" : "")
              .append(d.isEnabled() ? "" : "  (disabled)")
              .append("\n");
        }
        tvInputs.setText(sb.toString().trim());
        if (hasRotaryDevice) {
            tvRotary.setText("旋转编码器设备：有 ✔");
            tvRotary.setTextColor(ACCENT);
        } else {
            tvRotary.setText("旋转编码器设备：无 ✘\n（注意：很多手表枚举不到它，但 ACTION_SCROLL 照样能收到 —— 看下面的计数）");
            tvRotary.setTextColor(KEY);
        }
    }

    private void updateCrown() {
        tvCrownCount.setText("ACTION_SCROLL 次数：" + crownCount);
        tvCrownDelta.setText("累计 delta：" + one(crownDelta));
        tvCrownLast.setText("最近一次：" + crownLast);
    }

    private void updateTouch() {
        tvTouch.setText("单击 " + nClick + "  · 长按 " + nLong
                + "\n双击 " + nDouble + "  · 拖动 " + nDrag
                + "\n（单击要等 ~0.3 秒确认后才计数）");
    }

    private int[] physicalSize() {
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= 30) {
            Rect b = wm.getCurrentWindowMetrics().getBounds();
            return new int[]{b.width(), b.height()};
        }
        Point p = new Point();
        wm.getDefaultDisplay().getRealSize(p);
        return new int[]{p.x, p.y};
    }

    private int[] maxSize() {
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= 30) {
            Rect b = wm.getMaximumWindowMetrics().getBounds();
            return new int[]{b.width(), b.height()};
        }
        Point p = new Point();
        wm.getDefaultDisplay().getRealSize(p);
        return new int[]{p.x, p.y};
    }

    // ─────────────────── 表冠 / 按键 / 触摸 ───────────────────

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_SCROLL) {
            float a = ev.getAxisValue(MotionEvent.AXIS_SCROLL);
            float vs = ev.getAxisValue(MotionEvent.AXIS_VSCROLL);
            crownCount++;
            crownDelta += (a != 0f ? a : vs);
            crownLast = "axisScroll=" + one(a) + " axisVScroll=" + one(vs)
                    + " src=0x" + Integer.toHexString(ev.getSource());
            updateCrown();
        }
        return super.dispatchGenericMotionEvent(ev);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent ev) {
        tvLastKey.setText("最近按键：keyCode=" + keyCode
                + " (" + KeyEvent.keyCodeToString(keyCode) + ")"
                + "  src=0x" + Integer.toHexString(ev.getSource()));
        return super.onKeyDown(keyCode, ev);
    }

    // ───────────────────────── 小工具 ─────────────────────────

    private int dp(float v) { return Math.round(v * density); }

    private static String one(float v) { return String.format(Locale.US, "%.1f", v); }

    private static String two(float v) { return String.format(Locale.US, "%.2f", v); }

    private TextView makeTv(String text, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setLineSpacing(dp(2), 1f);
        return t;
    }

    private Button makeBtn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(11f);
        return b;
    }

    private void addTitle(LinearLayout parent, String text) {
        TextView t = makeTv(text, 12f, ACCENT, true);
        t.setPadding(0, dp(10), 0, dp(3));
        parent.addView(t);
    }

    private TextView addLine(LinearLayout parent, String text, float sp, int color) {
        return addLine(parent, text, sp, color, false);
    }

    private TextView addLine(LinearLayout parent, String text, float sp, int color, boolean bold) {
        TextView t = makeTv(text, sp, color, bold);
        parent.addView(t);
        return t;
    }
}
