package com.watchprobe.tool;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/**
 * 圆屏标尺（不写死任何机型尺寸，全部按 View 实际大小算）。
 *
 * 白圈  = 可视边界（描边内缩半个笔画宽度，保证自己完整可见，不会被边界砍一半）
 * 灰圈  = 向内 5% / 10% / 14% / 20% 的参考圈
 * 绿方  = 安全方（内接正方形，边长 = 直径/√2），关键内容别出这个方框
 * 黄刻度= 每 10dp 一格，每 50dp 加长
 */
public class RulerView extends View {

    private final Paint pEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pSafe = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pInner = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pTick = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pCross = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pBg = new Paint(Paint.ANTI_ALIAS_FLAG);

    private float cx, cy, R;
    private final float density;
    private boolean roundScreen = true;

    public RulerView(Context ctx) {
        super(ctx);
        density = ctx.getResources().getDisplayMetrics().density;
        setBackgroundColor(0xFF000000);

        pEdge.setStyle(Paint.Style.STROKE);
        pEdge.setStrokeWidth(2f * density);
        pEdge.setColor(0xFFFFFFFF);

        pRing.setStyle(Paint.Style.STROKE);
        pRing.setStrokeWidth(1f * density);
        pRing.setColor(0xFF7F8C8D);

        pSafe.setStyle(Paint.Style.STROKE);
        pSafe.setStrokeWidth(2f * density);
        pSafe.setColor(0xFF00E676);

        pInner.setStyle(Paint.Style.STROKE);
        pInner.setStrokeWidth(1f * density);
        pInner.setColor(0x6600E676);

        pTick.setStyle(Paint.Style.STROKE);
        pTick.setStrokeWidth(1f * density);
        pTick.setColor(0xFFFFD54F);

        pCross.setStyle(Paint.Style.STROKE);
        pCross.setStrokeWidth(1.5f * density);
        pCross.setColor(0xFFFF5252);

        pText.setColor(0xFFFFD54F);
        pText.setTextSize(9f * density);
        pText.setTextAlign(Paint.Align.CENTER);

        pBg.setStyle(Paint.Style.FILL);
        pBg.setColor(0xB3000000);
    }

    public void setRoundScreen(boolean round) {
        roundScreen = round;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        cx = w / 2f;
        cy = h / 2f;
        R = Math.min(w, h) / 2f;
    }

    @Override
    protected void onDraw(Canvas c) {
        if (R <= 0) return;

        // 可视边界：描边内缩半宽 → 自己不会被切
        float sw = pEdge.getStrokeWidth();
        c.drawCircle(cx, cy, R - sw / 2f, pEdge);

        // 参考圈
        float[] insets = {0.95f, 0.90f, 0.86f, 0.80f};
        for (float k : insets) c.drawCircle(cx, cy, R * k, pRing);

        // 安全方 + 其内切圆
        float h2 = R / 1.41421356f;
        c.drawRect(cx - h2, cy - h2, cx + h2, cy + h2, pSafe);
        c.drawCircle(cx, cy, h2, pInner);

        // 刻度：每 10dp 一格，每 50dp 加长（只画到 95% 半径，免得被边界切花）
        float step = 10f * density;
        int n = (int) (R * 0.95f / step);
        for (int i = 1; i <= n; i++) {
            float d = i * step;
            float len = (i % 5 == 0 ? 4f : 2f) * density;
            c.drawLine(cx + d, cy, cx + d, cy - len, pTick);
            c.drawLine(cx - d, cy, cx - d, cy - len, pTick);
            c.drawLine(cx, cy + d, cx + len, cy + d, pTick);
            c.drawLine(cx, cy - d, cx + len, cy - d, pTick);
            float dx = d * 0.70710678f;
            float t = len * 0.7f;
            c.drawLine(cx + dx, cy - dx, cx + dx + t, cy - dx - t, pTick);
            c.drawLine(cx - dx, cy - dx, cx - dx - t, cy - dx - t, pTick);
            c.drawLine(cx + dx, cy + dx, cx + dx + t, cy + dx + t, pTick);
            c.drawLine(cx - dx, cy + dx, cx - dx - t, cy + dx + t, pTick);
        }

        // 中心十字
        c.drawLine(cx - 8f * density, cy, cx + 8f * density, cy, pCross);
        c.drawLine(cx, cy - 8f * density, cx, cy + 8f * density, pCross);

        // 图例：先铺半透明底板，避免刻度和安全方边线压住文字（任意尺寸、任意机型都清晰）
        float asc = pText.getTextSize() * 0.95f, desc = pText.getTextSize() * 0.30f, pad = 5 * density;
        String hint = roundScreen ? "看哪一圈被圆边切掉" : "方屏：整屏都可画";
        String[] legend = {
                "白圈 = 可视边界",
                "R ≈ " + Math.round(R / density) + " dp (" + (int) R + " px)",
                "绿方 = 安全区",
                Math.round(2 * h2 / density) + " dp 见方",
                "刻度每格 10 dp"};
        float wHint = pText.measureText(hint), wLeg = 0;
        for (String s : legend) wLeg = Math.max(wLeg, pText.measureText(s));
        float hintBase = cy - R * 0.62f, legBase = cy + R * 0.80f;
        c.drawRoundRect(new RectF(cx - wHint / 2 - pad, hintBase - asc - pad,
                cx + wHint / 2 + pad, hintBase + desc + pad), 6 * density, 6 * density, pBg);
        c.drawRoundRect(new RectF(cx - wLeg / 2 - pad, cy + R * 0.24f - asc - pad,
                cx + wLeg / 2 + pad, legBase + desc + pad), 6 * density, 6 * density, pBg);

        pText.setColor(0xFFECEFF1);
        c.drawText(hint, cx, hintBase, pText);

        pText.setColor(0xFFFFFFFF);
        c.drawText(legend[0], cx, cy + R * 0.24f, pText);
        c.drawText(legend[1], cx, cy + R * 0.37f, pText);

        pText.setColor(0xFF00E676);
        c.drawText(legend[2], cx, cy + R * 0.50f, pText);
        c.drawText(legend[3], cx, cy + R * 0.62f, pText);

        pText.setColor(0xFFFFD54F);
        c.drawText(legend[4], cx, legBase, pText);
    }
}
