# app/ —— 源码与构建

## 文件

```
app/
├── src/com/watchprobe/tool/
│   ├── MainActivity.java     # 主页 + 表冠计数 + 按键记录 + 与标尺页互切
│   ├── TouchProbeView.java   # 触摸测试区（单击 / 长按 / 双击 / 拖动 四路计数）
│   └── RulerView.java        # 标尺页（可视边界 / R√2 / 安全方 / 10dp 刻度 / 十字中心）
├── template/                 # 打底 APK 模板（清单 + 资源表 + path-map.json）
└── scripts/build.sh          # 一条命令出包（缺签名密钥时自动生成一把）
```

三个类一共 630 行，没有任何 `res/layout`。

## 主页（`MainActivity`）

从上到下四块，整页可滚动（滚动位置本身也是观测项 —— 表冠转动时页面滚不滚，是「系统愿不愿意派发」的直接证据）：

| 区块 | 内容 |
|---|---|
| 屏幕信息 | 物理屏幕 / 应用窗口 / 最大窗口 / dp 尺寸 / 密度 / 是否圆屏 / 安全边距 / 系统栏内缩 / 刘海 |
| 表冠 / 旋转输入 | `旋转编码器：有 ✔ / 无 ✘` + 事件次数 + 累计 delta + 最近一次原始事件 + 页面滚动位置 |
| 触摸 / 按键 | 四种触摸计数 + `最近按键：<keyCode> (src 0x…)` |
| 输入设备 | 枚举出来的 `InputDevice` 列表（名称 / 源类型 / 是否外部） |

底部两个按钮：**标尺页**、**重置计数**。

关键实现：

- 表冠事件在 **`Activity.dispatchGenericMotionEvent`** 里记（不是 `onGenericMotionEvent`）——
  这样不管事件最终派给谁都能记到，并且 `return super` 让 `ScrollView` 照常滚动。
  **「数字变」和「页面滚」是两个独立结论**，不能互相代替。
- 读数取自 `DisplayMetrics` / `WindowInsets` / `Display.getRealSize` 等公开 API，只读不改。

## 触摸测试区（`TouchProbeView`）

内部一个 `GestureDetector`：`onSingleTapUp` / `onLongPress` / `onDoubleTap` / `onScroll` 分别 +1，
回调出去由 `MainActivity` 显示。

它自己 `requestDisallowInterceptTouchEvent(true)` 吃掉手指 —— 否则竖向拖动会被外层 `ScrollView`
当成页面滚动，就测不到「拖动」了。

## 标尺页（`RulerView`）

一屏画满同心圆和刻度，用来目测**哪一圈被系统圆角切掉**：

| 图元 | 含义 |
|---|---|
| 白圈（R × 1.0） | 屏幕可视边界（半径 = `min(w,h)/2`） |
| 细白圈（若干比例） | 参考同心圆 |
| 橙虚线方框（边长 = R/√2） | **理论安全区**：内接正方形，四角顶点正好落在圆周上 |
| 橙色刻度 | 每 10dp 一格，每 5 格加长 |
| 十字 + 中心点 | 屏幕中心，方便估偏移 |

圆屏上四角顶点只有 1px 余量，所以正文/按钮应落在**半径 ≤ 0.86R（≈100dp）**的圆里，
安全方只当硬上限用。

## 关于 `res/`

`res/layout/*.xml` 是模板自带的残留文件，**从来没被引用过** ——
`setContentView()` 收到的是 Java 造出来的 `FrameLayout`。
这么做的原因：避免重新编译 `resources.arsc`，也就避开了资源表重建的一系列玄学问题。
