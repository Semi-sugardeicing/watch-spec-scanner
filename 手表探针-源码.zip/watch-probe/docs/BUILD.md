# 构建说明（无 Gradle）

这个项目**不用 Gradle、不用 Android Studio、没有任何第三方依赖**。
所有视图都在 Java 里手写，`res/` 目录里的资源一次都没有被改过 —— 所以**不需要 aapt2 重新编资源**，
只要有一个能打包的 APK 模板 + 一个 `android.jar` + `d8` + `apksigner` 就够了。

## 一条命令

```sh
SDK=/path/to/android-sdk sh app/scripts/build.sh          # 产物 dist/watch-probe.apk
```

## 需要准备什么

| 变量 | 默认值 | 说明 |
|---|---|---|
| `ANDROID_HOME` / `SDK` | `~/Android/Sdk` | SDK 根目录，下面几项默认相对它 |
| `BUILD_TOOLS` | `$SDK/build-tools/34.0.0` | 里面要有 `d8`、`apksigner`（可选 `zipalign`） |
| `ANDROID_JAR` | `$SDK/platforms/android-34/android.jar` | 编译用（`-bootclasspath` / `-cp`） |
| `APKEDITOR_JAR` | `app/scripts/APKEditor.jar` | 从 [APKEditor releases](https://github.com/REAndroid/APKEditor/releases) 下 |
| `KEYSTORE` | `app/watch-probe.jks` | **不存在时脚本会现场生成一把自签密钥**（`CN=Watch Probe`，口令 `watchprobe`）—— 仓库里不含密钥 |

`app/template/` 是打底模板（未打包的 APK 目录：清单 + 资源表 + `path-map.json`）。
`APKEditor b` 会用它把编译出来的 `classes.dex` 重新塞回一个合法 APK 里。
模板里刻意**没有**包含 `.cache/` 和 `root/classes.dex` 这两个二进制残留 —— 实测去掉之后依然能正常出包。

## 流程

```
javac -encoding UTF-8 -source 8 -target 8   →  build/classes/**.class
d8 --min-api 23                             →  build/dex/classes.dex
cp template + classes.dex                   →  build/pack/
APKEditor.jar b                             →  build/unsigned.apk
apksigner sign (+ zipalign 可选)            →  dist/watch-probe.apk
```

## 换包名 / 改 App 名

包名 `com.watchprobe.tool` 写在**三处**，必须一起改，否则装不上：

- `app/template/AndroidManifest.xml` 的 `package`
- `app/template/resources/package_1/package.json`
- `app/template/resources/package_1/res/values/public.xml` 的 `package`

Java 源码目录（`app/src/com/watchprobe/tool/`）和三个文件里的 `package` 语句也要跟着改。

App 名改 `app/template/resources/package_1/res/values/strings.xml` 里的 `app_name`（当前是「手表探针」）。

## 这个构建方式是怎么来的

手表上装不了 Android Studio 那套东西，所以整条链路只依赖四个 CLI 工具。
第一次要打包时用的是别人做好的 APK 模板，改包名后把编译产物直接替换 `classes.dex` 即可 ——
好处是**完全不用碰 `resources.arsc`**，也就不会遇到资源表重建的各种玄学问题。

## 本次发布的产物

```
dist/watch-probe.apk      58306 字节
签名                      CN=Watch Probe（作者自用密钥，未随仓库分发）
SHA-256 (APK)             e1f8c1ca47bb94d207217a20fc50d6868a3ef1f215e7d1d84ffda47ac2c42f03
证书 SHA-256              d466bee41108ae47dc4a617261353174d3d79452e2ff60b9872febf6a17fc703
系统要求                  Android 6.0 (API 23) 及以上
```

（APK 的 SHA-256 会随构建环境略有浮动 —— `d8` 版本不同、`zipalign` 有无都会改变字节；
证书指纹则只跟签名密钥有关。）

> ⚠️ **自己构建出来的 APK 签名和上面的不一样。**
> 仓库里**没有**发布用的密钥，`build.sh` 会现场生成一把（`CN=Watch Probe`，口令 `watchprobe`），
> 所以源码构建的包**不能覆盖安装**在 `dist/watch-probe.apk` 之上 —— 两者证书不同，想换只能先卸载。
