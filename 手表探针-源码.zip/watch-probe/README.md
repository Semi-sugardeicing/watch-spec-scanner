# 手表探针 · Watch Probe

[![minSdk](https://img.shields.io/badge/minSdk-23-3ddc84)](#)
[![依赖](https://img.shields.io/badge/依赖-零第三方-4ecda4)](#)
[![权限](https://img.shields.io/badge/权限-无-blue)](#)

给 **圆屏 Android 手表** 用的一个探针 App：**装上去，一眼看清这台表到底给了 App 多大的屏幕、表冠能不能用、触摸正不正常。**

写它的起因很实在 —— 想给手表写个界面，但不知道可用窗口有多大、是不是圆屏、表冠旋转事件到底进不进得来。
网上查不到（每台表都不一样），于是直接做个 App 上机测。

理论上任何 Android 手表都能装（`minSdk 23` / Android 6.0+），实测机型：**OPPO Watch X2**
（466×466 圆屏 · Android 11 / API 30 · 320dpi）。

## 预览

> 按源码坐标常量渲染的界面示意（不是实机截图）：深色主页 / 标尺页 / 浅色主页。

![三页示意](docs/preview.png)

## 它回答三个问题

| 问题 | 屏幕上怎么看 |
|---|---|
| **屏幕真实参数** | 顶部固定小结：`SDK · 圆屏 · 分辨率 · dpi`；下面滚动区给出 px / dp / 应用窗口 / 最大窗口 / systemBars·cutout 四边内缩 |
| **表冠有没有、App 收不收得到** | `旋转编码器：有 ✔ / 无 ✘` + **事件次数 / 累计 delta 实时跳**；同时观察本页能不能被表冠滚动 |
| **触摸正不正常** | 触摸测试区里点 / 长按 / 双击 / 拖，四种计数分别累加 |

外加一个 **标尺页**（底部按钮切换）：白圈 = 可视边界、细白圈 = R/√2、绿方 = 理论安全区、橙色刻度每格 10dp，
用来目测**哪一圈被系统圆角切掉**。

## 两个容易踩的坑（这个 App 存在的意义）

1. **表冠不能用 `SOURCE_ROTARY_ENCODER` 判断。**
   实测表把旋转编码器报成了 **`SOURCE_MOUSE`**（`src = 0x2002`），`InputDevice` 枚举里根本没有 `SOURCE_ROTARY_ENCODER`。
   → 如果按官方那套判据写代码，探针会显示「无 ✘」，而实际上 `ACTION_SCROLL` **收得到**（累计 delta 上千）。
   **唯一可靠的判据是实收 `ACTION_SCROLL`**，并且要在 `dispatchGenericMotionEvent` 里收、`return super` 别吞，否则页面滚不动。

2. **圆角裁切不会出现在 `WindowInsets` 里。**
   实测四边内缩全是 0、可用窗口 = 最大窗口 = 全屏，但圆角实实在在地切掉了四角。
   → 关键内容要落在**内接正方形**（边长 = 466/√2 ≈ 164.7dp，四边各留 34dp）里；标尺页正是为此画的。

## 安装

下载 [`dist/watch-probe.apk`](dist/watch-probe.apk) → 传到手表安装（`adb install` 或手表端文件管理器）。

签名是自签的（`CN=Watch Probe`），装之前需要在手表上允许「安装未知来源应用」。

```sh
adb install -r dist/watch-probe.apk
```

## 怎么读结果

打开「手表探针」，按下面三步走：

1. **屏幕**：记下 `物理屏幕` / `应用窗口` / `圆屏` / `安全边距` 四个值。写 UI 时用 `应用窗口`，
   布局时按 `安全边距` 内缩。四边内缩全 0 是正常的（圆角不进 insets）。
2. **表冠**：转一下表冠，看 `事件次数` 和 `累计 delta` 有没有动（动 = 收得到），
   再看本页能不能上下滚（能滚 = 系统愿意把事件派发给 App）。**这是两个独立结论**。
3. **触摸**：在触摸测试区里依次单击 / 长按 / 双击 / 拖动，四个计数都该 +1。

物理按键会显示在 `最近按键`（实测 OPPO Watch X2 的表冠按压 = `KEYCODE_F1` / `src 0x101`）。

## 能力边界

- **不联网、不读存储、不定位** —— `AndroidManifest.xml` 里一个 `<uses-permission>` 都没有。
- 只读系统给的公开信息（`DisplayMetrics` / `WindowInsets` / `InputDevice`），不改任何设置。
- 表冠按压、返回键这类事件只是**记录下来**，不拦不吞。

## 构建

无 Gradle、无 Android Studio、**零第三方依赖**，`javac → d8 → APKEditor → apksigner` 一条命令出包。

```sh
SDK=/path/to/android-sdk sh app/scripts/build.sh    # 产物 dist/watch-probe.apk
```

需要 `build-tools`（`d8` / `apksigner`）、任意一个 platform 的 `android.jar`、以及
[APKEditor.jar](https://github.com/REAndroid/APKEditor/releases)。所有路径都能用环境变量覆盖，
详见 [`docs/BUILD.md`](docs/BUILD.md)。

UI 全部在 Java 里手写视图搭出来，**没有改动任何 `res/` 资源**，所以不需要 `aapt2` 重新编资源。

## 仓库结构

```
watch-probe/
├── app/
│   ├── src/com/watchprobe/tool/
│   │   ├── MainActivity.java     # 主页：屏幕信息 / 表冠计数 / 触摸计数 / 按键记录
│   │   ├── TouchProbeView.java   # 触摸测试区（单击·长按·双击·拖动四路计数）
│   │   └── RulerView.java        # 标尺页（可视边界 / R√2 / 安全方 / 10dp 刻度）
│   ├── template/                 # 打底 APK 模板（清单 + 资源表 + path-map.json）
│   └── scripts/build.sh          # 一条命令出包（缺密钥时自动生成）
├── dist/watch-probe.apk          # 签名产物
└── docs/{BUILD.md,preview.png}
```

仓库里**不含任何签名密钥** —— `build.sh` 找不到密钥时会现场生成一把自签的。

## License

[MIT](LICENSE)

---

### English

A tiny diagnostic probe for round-screen Android watches (built for OPPO Watch X2, 466×466 /
Android 11, but any Android 6.0+ watch should work). It shows exactly what the system hands to an
app: the real display metrics, whether crown rotation events actually reach you, and whether touch
works. There is also a ruler page for eyeballing how much the round corners crop.

Two findings worth knowing before you write a watch UI:

- Crown rotation may be reported as **`SOURCE_MOUSE`**, not `SOURCE_ROTARY_ENCODER`. Don't filter on
  the source type — count `ACTION_SCROLL` in `dispatchGenericMotionEvent` instead.
- Round-corner cropping **never appears in `WindowInsets`** (all four insets can be 0). Keep content
  inside the inscribed square: `radius / √2`.

Zero permissions, zero third-party dependencies, and no XML layouts — the whole UI is built in Java
at runtime, so `resources.arsc` is never recompiled. See `docs/BUILD.md` for the Gradle-free build.
