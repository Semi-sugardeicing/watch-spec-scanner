package com.minis.dsbalance;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/**
 * DeepSeek 余额 · 手表版 v4（2026-10-02）
 *
 * v4 = v3 原地换页 + 「可诊断」改造（见 docs/ERROR_LOG.md E4/E5）：
 *   · ★ 屏幕顶部常驻一行自证：`P1  v4·1.1` / `D3 U3 dy-45 m-56`
 *     —— 装完先看版本号（v4·1.1 才对），滑一次就能看出触摸到底有没有到 App、位移够不够；
 *   · ★ 屏幕底部常驻一颗「▼ 下一屏」按钮：点一下就换一屏（到头绕回第 1 屏）。
 *     换页从此有三条通道：点按钮（主轴，唯一实机验证过「点得动」的输入）、
 *     手指上/下滑、表冠旋转 —— 任何一条坏了都不至于全盘失能；
 *   · 滑动阈值放宽：28dp / 比例 1.0（v3 是 60dp / 1.2，很可能就是「滑了没反应」的原因）；
 *   · 三屏内容、原地换页机制与 v3 完全一致（removeAllViews + addView，无 translation / 无动画）。
 *
 * 三窗一窗一件事（见 docs/ERROR_LOG.md）：
 *   窗 1 · 余额   标题 / 大号金额 / 状态行（居中三行）
 *   窗 2 · 刷新   状态行 / 大圆钮 / 按钮下方就地状态文字   ★ 全 App 唯一发请求的地方
 *   窗 3 · Key    列表（点=切换、长按=删除）+ 添加
 *
 * 布局全部 Java 手搓，不动任何 res 资源。铁律：不监听表冠按压（keyCode 131 会退出 App）；
 * 不自动刷新（只有窗 2 那颗圆钮会发请求）。
 */
public class MainActivity extends Activity {

    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;

    static final int W_BALANCE = 0;      // 窗 1
    static final int W_REFRESH = 1;      // 窗 2
    static final int W_KEYS    = 2;      // 窗 3
    static final int PAGES     = 3;

    static final String VER = "v4·1.1";           // 屏幕顶部常驻：改版就改这里 + 清单 versionCode/Name

    static final int KEY_MAX_ROWS = 2;            // 窗 3 最多列 2 把 Key（再多会和「添加」抢位置）

    static final long CROWN_COOLDOWN_MS = 250L;   // 表冠去抖
    static final float CROWN_STEP = 2.0f;
    static final float SWIPE_MIN_DP = 28f;        // 手指滑动的最小纵向位移（v3 是 60dp，实机嫌大）
    static final float SWIPE_RATIO = 1.0f;        // 竖向优先：|dy| 大于 |dx| 即可（v3 要求 1.2 倍）

    static final long HINT_SHORT_MS = 1500L;
    static final long HINT_LONG_MS = 2000L;
    static final long HINT_ADD_MS = 2500L;

    KeyStore store;
    final Throttle throttle = new Throttle();
    BalanceApi api;
    SwipeThemeDetector swipe;

    FrameLayout root, stage;
    final FrameLayout[] pages = new FrameLayout[PAGES];

    TextView tvTitle, tvBalance, tvStatusA;          // 窗 1
    TextView tvStatusB, tvRefresh, tvRefreshMsg;     // 窗 2
    TextView tvKeyTitle, tvAdd;                      // 窗 3
    LinearLayout keyListBox;

    TextView tvHint;
    TextView tvDebug;                                // ★ 顶部常驻自证行（版本号 + 页号 + 触摸计数）
    TextView btnNext;                                // ★ 底部常驻「▼ 下一屏」
    FrameLayout dialogOverlay;
    LinearLayout dialogCard;
    TextView dialogTitle;
    EditText dialogInput;
    LinearLayout dialogButtons;

    int page = W_BALANCE;
    int selectedRow = 0;
    int downCount = 0, upCount = 0;                  // 触摸自证计数
    float lastDy = 0f, maxDy = 0f;                   // 末次手势的纵向位移 / 本次手势的最大纵向位移
    float crownAccum = 0f;
    long lastCrownMs = 0L;
    float downX = 0f, downY = 0f;
    boolean swipeLocked = false;
    boolean inFlight = false;
    boolean punishing = false;
    boolean dark = true;
    long statusToken = 0L;

    final Handler h = new Handler(Looper.getMainLooper());

    // ------------------------------------------------------------------ 生命周期

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        store = new KeyStore(this);
        api = new BalanceApi();
        dark = (store.themeMode() != Theme.LIGHT);
        getWindow().setBackgroundDrawable(new ColorDrawable(Theme.bg(dark)));

        swipe = new SwipeThemeDetector(new SwipeThemeDetector.Callback() {
            public void onRightToLeft() {
                toggleTheme();
            }
        }, dp(60), dp(40), 200f);

        buildUi();

        selectedRow = store.currentIndex();
        page = clampPage(store.page());
        showWindowNow(page);

        applyTheme();
        updateAll();
        handleInject(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleInject(intent);
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        if (api != null) api.shutdown();
        super.onDestroy();
    }

    static int clampPage(int p) {
        if (p < 0) return W_BALANCE;
        if (p > PAGES - 1) return PAGES - 1;
        return p;
    }

    // ------------------------------------------------------------------ 界面搭建

    int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    TextView mkText(String s, float sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setIncludeFontPadding(false);
        t.setTextColor(Theme.mainText(dark));
        return t;
    }

    /** 放进页面后，以「屏幕中心」为原点做纵向偏移（每个元素按半径 100dp 校验过） */
    void place(FrameLayout p, View v, float yDp) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER);
        p.addView(v, lp);
        v.setTranslationY(dp(yDp));
    }

    void buildUi() {
        root = new FrameLayout(this);

        // ★ 唯一的可见容器：任何时候里面只挂当前这一屏
        stage = new FrameLayout(this);
        root.addView(stage, new FrameLayout.LayoutParams(MATCH, MATCH));

        pages[W_BALANCE] = new FrameLayout(this);
        pages[W_REFRESH] = new FrameLayout(this);
        pages[W_KEYS]    = new FrameLayout(this);
        buildBalance(pages[W_BALANCE]);
        buildRefresh(pages[W_REFRESH]);
        buildKeys(pages[W_KEYS]);

        // ★ 顶部常驻自证行：版本号 + 当前页号 + 触摸计数（v4 新增，见 ERROR_LOG E4）
        //   两行 9sp，落在圆的 −84dp（包围盒角半径 ≈96dp，在 100dp 安全圈内）
        tvDebug = new TextView(this);
        tvDebug.setTextSize(9f);
        tvDebug.setGravity(Gravity.CENTER);
        tvDebug.setIncludeFontPadding(false);
        tvDebug.setLineSpacing(0f, 1.1f);
        root.addView(tvDebug, new FrameLayout.LayoutParams(dp(120), WRAP, Gravity.CENTER));
        tvDebug.setTranslationY(dp(-84f));

        // ★ 底部常驻「▼ 下一屏」：点击换页（唯一被实机反复验证过的输入方式）
        btnNext = new TextView(this);
        btnNext.setTextSize(10f);
        btnNext.setGravity(Gravity.CENTER);
        btnNext.setIncludeFontPadding(false);
        btnNext.setPadding(dp(12), dp(5), dp(12), dp(5));
        btnNext.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // 到头绕回第 1 屏：保证只靠点击也能逛完全部三屏
                int nxt = (page + 1) % PAGES;
                showWindow(nxt);
                tempStatus("第 " + (nxt + 1) + " 屏", HINT_SHORT_MS);
            }
        });
        root.addView(btnNext, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER));
        btnNext.setTranslationY(dp(84f));

        // 中央提示（节流刹车用，默认隐藏）
        tvHint = new TextView(this);
        tvHint.setTextSize(14f);
        tvHint.setGravity(Gravity.CENTER);
        tvHint.setIncludeFontPadding(false);
        tvHint.setPadding(dp(16), dp(10), dp(16), dp(10));
        tvHint.setVisibility(View.GONE);
        root.addView(tvHint, new FrameLayout.LayoutParams(dp(160), WRAP, Gravity.CENTER));

        // 对话框层（添加 / 删除确认）
        dialogOverlay = new FrameLayout(this);
        dialogOverlay.setVisibility(View.GONE);
        dialogOverlay.setClickable(true);
        dialogCard = new LinearLayout(this);
        dialogCard.setOrientation(LinearLayout.VERTICAL);
        dialogCard.setGravity(Gravity.CENTER_HORIZONTAL);
        dialogCard.setPadding(dp(10), dp(10), dp(10), dp(10));

        dialogTitle = new TextView(this);
        dialogTitle.setTextSize(14f);
        dialogTitle.setGravity(Gravity.CENTER);
        dialogTitle.setIncludeFontPadding(false);
        dialogCard.addView(dialogTitle, new LinearLayout.LayoutParams(WRAP, WRAP));

        dialogInput = new EditText(this);
        dialogInput.setTextSize(13f);
        dialogInput.setSingleLine(true);
        dialogInput.setHint("sk-...");
        dialogInput.setVisibility(View.GONE);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(150), WRAP);
        ilp.topMargin = dp(6);
        dialogCard.addView(dialogInput, ilp);

        dialogButtons = new LinearLayout(this);
        dialogButtons.setOrientation(LinearLayout.HORIZONTAL);
        dialogButtons.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(WRAP, WRAP);
        blp.topMargin = dp(8);
        dialogCard.addView(dialogButtons, blp);

        FrameLayout.LayoutParams cardLp = new FrameLayout.LayoutParams(dp(178), WRAP, Gravity.CENTER);
        dialogOverlay.addView(dialogCard, cardLp);
        root.addView(dialogOverlay, new FrameLayout.LayoutParams(MATCH, MATCH));

        setContentView(root);
    }

    /** 窗 1 · 余额：居中三行 */
    void buildBalance(FrameLayout p) {
        tvTitle = mkText("DeepSeek 余额", 12f);
        place(p, tvTitle, -56f);

        tvBalance = mkText("—", 42f);
        tvBalance.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        place(p, tvBalance, 0f);

        // 状态行（窗 2 有同一句话的孪生行，但那两屏不同屏，位置各自独立）
        tvStatusA = mkText("点击刷新", 11f);
        place(p, tvStatusA, 52f);
    }

    /** 窗 2 · 刷新：全 App 唯一的发请求入口 */
    void buildRefresh(FrameLayout p) {
        tvStatusB = mkText("点击刷新", 11f);
        place(p, tvStatusB, -62f);

        tvRefresh = mkText("刷新", 15f);
        tvRefresh.setGravity(Gravity.CENTER);
        tvRefresh.setIncludeFontPadding(false);
        FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(dp(68), dp(68), Gravity.CENTER);
        p.addView(tvRefresh, rlp);
        tvRefresh.setTranslationY(dp(6f));
        tvRefresh.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                onRefreshClick();
            }
        });

        // 按钮下方就地状态文字：刷新中… / 错误原因（成功不留字，空闲隐藏）
        tvRefreshMsg = mkText("", 11f);
        tvRefreshMsg.setGravity(Gravity.CENTER);
        tvRefreshMsg.setVisibility(View.GONE);
        place(p, tvRefreshMsg, 50f);         // v4：由 +56 上移，给底部「▼ 下一屏」（+84）让位
    }

    /** 窗 3 · Key 管理 */
    void buildKeys(FrameLayout p) {
        tvKeyTitle = mkText("API KEY", 12f);
        place(p, tvKeyTitle, -64f);          // v4：由 −84 下移，给顶部自证行让位

        keyListBox = new LinearLayout(this);
        keyListBox.setOrientation(LinearLayout.VERTICAL);
        keyListBox.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout.LayoutParams klp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER);
        p.addView(keyListBox, klp);
        keyListBox.setTranslationY(dp(-8f));

        tvAdd = mkText("添加", 14f);
        tvAdd.setPadding(dp(16), dp(8), dp(16), dp(8));
        place(p, tvAdd, 44f);                // v4：由 +78 上移，给底部「▼ 下一屏」（+84）让位
        tvAdd.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showAddDialog();
            }
        });
    }

    /** 重建 Key 列表（含高亮样式） */
    void rebuildKeyRows() {
        if (keyListBox == null) return;
        keyListBox.removeAllViews();
        List<KeyStore.Entry> l = store.list();

        if (l.isEmpty()) {
            TextView t = mkText("（还没有 Key）", 13f);
            t.setTextColor(Theme.secondary(dark));
            t.setPadding(dp(8), dp(6), dp(8), dp(6));
            keyListBox.addView(t);
            selectedRow = 0;
            return;
        }
        if (selectedRow < 0 || selectedRow >= l.size()) selectedRow = 0;

        int cur = store.currentIndex();
        int shown = l.size() > KEY_MAX_ROWS ? KEY_MAX_ROWS : l.size();
        for (int i = 0; i < shown; i++) {
            final int idx = i;
            KeyStore.Entry e = l.get(i);
            boolean sel = (idx == selectedRow);
            TextView t = mkText(e.name + (idx == cur ? "   当前" : ""), 13f);
            t.setPadding(dp(12), dp(6), dp(12), dp(6));
            t.setBackground(Theme.rounded(sel ? Theme.rowSel(dark) : Theme.rowFill(dark),
                    sel ? Theme.accent(dark) : 0, dp(10)));
            t.setTextColor(sel ? Theme.accent(dark) : Theme.mainText(dark));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.bottomMargin = dp(4);
            keyListBox.addView(t, lp);

            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    boolean changed = (idx != store.currentIndex());
                    selectedRow = idx;
                    if (changed) store.setCurrent(idx);
                    rebuildKeyRows();
                    updateAll();
                    if (changed) tempStatus("已切到 " + store.nameAt(idx), HINT_LONG_MS);
                }
            });
            t.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) {
                    selectedRow = idx;
                    rebuildKeyRows();
                    showDeleteDialog(idx);
                    return true;
                }
            });
        }
    }

    // ------------------------------------------------------------------ 换页（★ 原地换，无平移、无动画）

    /**
     * 把所有内容换掉：stage 里永远只挂当前这一屏。
     * 绝不用 translation 把页面摆到屏幕外 —— 那正是 v2 白屏的原因（clipChildren 会把屏幕外的孩子裁掉）。
     */
    void showWindow(int p) {
        p = clampPage(p);
        if (p == page && stage.getChildCount() > 0) return;
        store.setPage(p);
        page = p;
        showWindowNow(p);
    }

    /** 冷启动用：不做「同页就返回」的短路，确保一定挂上去 */
    void showWindowNow(int p) {
        stage.removeAllViews();
        stage.addView(pages[p], new FrameLayout.LayoutParams(MATCH, MATCH));
        updateDebug();
    }

    // ------------------------------------------------------------------ ★ 自证行（v4 诊断用）

    /**
     * 屏幕顶部常驻两行：
     *   `P2  v4·1.1`            ← 第几屏（1~3）+ 版本号（装完先核对这里）
     *   `D3 U3 dy-45 m-56`      ← DOWN/UP 次数 + 末次手势 dy + 本次手势最大 |dy|（单位 px，density 2 → 28dp = 56px）
     * 读法：
     *   D/U 一直是 0            → 触摸事件根本没到 App（系统手势 / 窗口属性问题）
     *   D/U 有数、m 明显 <56    → 就是阈值问题（滑动幅度太小）
     *   m ≥56 却没换屏          → 换页逻辑的问题（showWindow）
     */
    void updateDebug() {
        if (tvDebug == null) return;
        tvDebug.setText("P" + (page + 1) + "  " + VER
                + "\nD" + downCount + " U" + upCount
                + " dy" + Math.round(lastDy) + " m" + Math.round(maxDy));
        if (btnNext != null) {
            btnNext.setText(page >= PAGES - 1 ? "▼ 回第 1 屏" : "▼ 下一屏");
        }
    }

    // ------------------------------------------------------------------ 主题

    void applyTheme() {
        int bg = Theme.bg(dark);
        int sec = Theme.secondary(dark);
        int acc = Theme.accent(dark);
        int fg = Theme.mainText(dark);

        root.setBackgroundColor(bg);
        tvTitle.setTextColor(sec);
        tvStatusA.setTextColor(sec);
        tvStatusB.setTextColor(sec);
        tvRefreshMsg.setTextColor(sec);
        tvKeyTitle.setTextColor(sec);
        tvBalance.setTextColor(acc);
        tvAdd.setTextColor(acc);

        tvRefresh.setBackground(Theme.circle(Theme.btnFill(dark), acc));
        tvRefresh.setTextColor(acc);

        tvDebug.setTextColor(sec);                                   // 自证行：次要色，别抢戏
        btnNext.setBackground(Theme.rounded(Theme.rowFill(dark), acc, dp(14)));
        btnNext.setTextColor(acc);

        tvHint.setBackground(Theme.rounded(Theme.cardFill(dark), sec, dp(12)));
        tvHint.setTextColor(fg);

        dialogCard.setBackground(Theme.rounded(Theme.dialogFill(dark), sec, dp(12)));
        dialogTitle.setTextColor(fg);
        dialogInput.setTextColor(fg);
        dialogOverlay.setBackgroundColor(dark ? 0x99000000 : 0x66FFFFFF);
        for (int i = 0; i < dialogButtons.getChildCount(); i++) {
            View v = dialogButtons.getChildAt(i);
            if (v instanceof TextView) ((TextView) v).setTextColor(acc);
        }

        rebuildKeyRows();
        refreshEnable(!punishing && !inFlight);
    }

    void toggleTheme() {
        dark = !dark;
        store.setThemeMode(dark ? Theme.DARK : Theme.LIGHT);
        applyTheme();
        tempStatus("已切换：" + (dark ? "暗色" : "亮色"), HINT_LONG_MS);
    }

    // ------------------------------------------------------------------ 状态行（两窗同一句话）

    void setStatusRaw(String s) {
        if (tvStatusA != null) tvStatusA.setText(s);
        if (tvStatusB != null) tvStatusB.setText(s);
    }

    /** 立即改状态行，并作废一切挂起的「临时提示」 */
    void setStatusNow(String s) {
        statusToken++;
        setStatusRaw(s);
    }

    /** 临时提示（切主题 / 切 Key / 已添加…），到时自动回到「最后刷新」 */
    void tempStatus(final String s, long ms) {
        statusToken++;
        final long tk = statusToken;
        setStatusRaw(s);
        h.postDelayed(new Runnable() {
            public void run() {
                if (tk == statusToken) updateStatusText();
            }
        }, ms);
    }

    void updateStatusText() {
        statusToken++;
        if (store.list().isEmpty()) {
            setStatusRaw("未设置 Key");
            return;
        }
        long ms = store.lastRefresh();
        if (ms <= 0L) {
            setStatusRaw("点击刷新");
            return;
        }
        setStatusRaw("最后刷新 " + TimeFmt.hhmm(ms));
    }

    /** 窗 2 按钮下方的就地状态文字（null/空 = 隐藏） */
    void refreshMsg(String s) {
        if (tvRefreshMsg == null) return;
        if (s == null || s.length() == 0) {
            tvRefreshMsg.setText("");
            tvRefreshMsg.setVisibility(View.GONE);
        } else {
            tvRefreshMsg.setText(s);
            tvRefreshMsg.setVisibility(View.VISIBLE);
        }
    }

    void updateAll() {
        updateStatusText();
    }

    // ------------------------------------------------------------------ 中央提示

    final Runnable hideHint = new Runnable() {
        public void run() {
            if (!punishing) tvHint.setVisibility(View.GONE);
        }
    };

    void showHint(String line1, String line2, long ms) {
        if (punishing) return;
        tvHint.setText((line2 == null || line2.length() == 0) ? line1 : (line1 + "\n" + line2));
        tvHint.setVisibility(View.VISIBLE);
        h.removeCallbacks(hideHint);
        h.postDelayed(hideHint, ms);
    }

    // ------------------------------------------------------------------ 刷新 + 节流

    void refreshEnable(boolean en) {
        if (en && punishing) return;
        tvRefresh.setEnabled(en);
        tvRefresh.setClickable(en);
        tvRefresh.setAlpha(en ? 1f : 0.35f);
    }

    void onRefreshClick() {
        KeyStore.Entry e = store.current();
        if (e == null) {
            refreshMsg("未设置 Key");
            showHint("未设置 Key", "先添加一把 API Key", HINT_LONG_MS);
            return;
        }
        if (inFlight) return;                                  // ① 飞行中：不发、不排队

        long now = SystemClock.uptimeMillis();
        int r = throttle.request(now);
        if (r == Throttle.TOO_SOON) {                          // ② 最小间隔 3 秒
            showHint("过于频繁", "请稍后尝试", HINT_SHORT_MS);
            return;
        }
        if (r == Throttle.PUNISHED) {                          // ③ 已在惩罚期（只刷新倒计时，绝不延长）
            startPunish();
            return;
        }
        if (throttle.punishRemain(now) > 0L) startPunish();     // 本次点击刚好触发惩罚
        doRequest(e);
    }

    void doRequest(KeyStore.Entry e) {
        inFlight = true;
        refreshEnable(false);
        refreshMsg("刷新中…");                                  // 常住行仍显示「最后刷新」，不抢
        api.query(e.key, new BalanceApi.Callback() {
            public void onOk(String bal, String cur) {
                inFlight = false;
                refreshEnable(true);
                store.setLastResult(bal, cur);
                tvBalance.setText(symbolOf(cur) + bal);
                updateStatusText();
                refreshMsg(null);                               // 成功不留字
                showWindow(W_BALANCE);                          // 自动翻回窗 1，让人当场看到新金额
            }

            public void onFail(String msg) {
                inFlight = false;
                refreshEnable(true);
                updateStatusText();                             // 常住行回到「最后刷新 15:42」
                refreshMsg(msg);                                // 失败原因留在按钮下方
            }
        });
    }

    static String symbolOf(String cur) {
        if (cur == null) return "";
        if ("CNY".equalsIgnoreCase(cur)) return "¥";
        if ("USD".equalsIgnoreCase(cur)) return "$";
        return cur + " ";
    }

    // ---- 惩罚期（固定 10 秒，期间点击不延长） ----

    final Runnable punishTick = new Runnable() {
        public void run() {
            long now = SystemClock.uptimeMillis();
            long remain = throttle.punishRemain(now);
            if (remain <= 0L) {
                punishing = false;
                tvHint.setVisibility(View.GONE);
                refreshEnable(true);
                return;
            }
            long sec = (remain + 999L) / 1000L;
            tvHint.setText("过于频繁\n请稍后尝试（" + sec + "）");
            tvHint.setVisibility(View.VISIBLE);
            h.postDelayed(this, 200L);
        }
    };

    void startPunish() {
        if (punishing) return;
        punishing = true;
        h.removeCallbacks(hideHint);
        refreshEnable(false);
        h.post(punishTick);
    }

    // ------------------------------------------------------------------ 表冠（附加通道）

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent ev) {
        if (ev != null && ev.getAction() == MotionEvent.ACTION_SCROLL) {
            float a = ev.getAxisValue(MotionEvent.AXIS_SCROLL);
            float v = ev.getAxisValue(MotionEvent.AXIS_VSCROLL);
            float d = (a != 0f) ? a : v;
            if (d != 0f) {
                long t = ev.getEventTime();
                if (t - lastCrownMs >= CROWN_COOLDOWN_MS) {
                    crownAccum += d;
                    if (crownAccum <= -CROWN_STEP) {
                        crownAccum = 0f;
                        lastCrownMs = t;
                        onCrown(-1);
                    } else if (crownAccum >= CROWN_STEP) {
                        crownAccum = 0f;
                        lastCrownMs = t;
                        onCrown(+1);
                    }
                }
            }
            // 已自行消费：本 App 全屏前台、翻窗由自己驱动
            return true;
        }
        return super.dispatchGenericMotionEvent(ev);
    }

    /**
     * dir = -1：往「下一窗」方向；dir = +1：往「上一窗」方向。到头停住、不循环。
     */
    void onCrown(int dir) {
        if (page == W_BALANCE) {                    // 窗 1：只能往窗 2
            if (dir < 0) showWindow(W_REFRESH);
            return;
        }
        if (page == W_REFRESH) {                    // 窗 2：两头都能去
            showWindow(dir < 0 ? W_KEYS : W_BALANCE);
            return;
        }
        // 窗 3：先在高亮项之间上下走，走到顶再退回窗 2
        List<KeyStore.Entry> l = store.list();
        if (dir < 0) {
            if (selectedRow < l.size() - 1) {
                selectedRow++;
                rebuildKeyRows();
            }
        } else {
            if (selectedRow > 0) {
                selectedRow--;
                rebuildKeyRows();
            } else {
                showWindow(W_REFRESH);
            }
        }
    }

    // ------------------------------------------------------------------ 手势（主轴：上下滑翻窗；横向：右→左切主题）

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        pageSwipe(ev);          // 统计 + 翻窗（内部自行判断对话框是否在前）
        if (dialogOverlay != null && dialogOverlay.getVisibility() != View.VISIBLE) {
            swipe.onTouch(ev);  // 只旁听：横向右→左切主题
        }
        return super.dispatchTouchEvent(ev);
    }

    /** 手指是否正落在某个控件上（用屏幕坐标，能正确计入 translationY；detached 的页面一律 false） */
    boolean hit(View v, MotionEvent ev) {
        if (v == null || !v.isShown()) return false;      // isShown：自身及祖先都 VISIBLE 且已 attach
        if (v.getWidth() == 0 || v.getHeight() == 0) return false;
        int[] p = new int[2];
        v.getLocationOnScreen(p);
        float x = ev.getRawX(), y = ev.getRawY();
        return x >= p[0] && x <= p[0] + v.getWidth() && y >= p[1] && y <= p[1] + v.getHeight();
    }

    /**
     * 手指上滑 = 下一窗，下滑 = 上一窗；一次手势只换一屏；到头停住不循环。
     * 顺带把 DOWN/UP 次数与位移写进顶部自证行（v4 新增，见 ERROR_LOG E4）。
     */
    void pageSwipe(MotionEvent ev) {
        if (ev == null) return;
        int a = ev.getActionMasked();

        if (a == MotionEvent.ACTION_DOWN) {
            downX = ev.getX();
            downY = ev.getY();
            maxDy = 0f;
            downCount++;
            // ★ 手指落在可点控件上（▼下一屏 / 刷新圆钮 / 添加 / Key 行）→ 本次手势不翻窗，
            //   否则 ACTION_UP 会先被这里翻一屏、再被控件的 onClick 点一次 → 双触发
            swipeLocked = hit(btnNext, ev) || hit(tvRefresh, ev) || hit(tvAdd, ev) || hit(keyListBox, ev);
            updateDebug();
            return;
        }
        if (a == MotionEvent.ACTION_MOVE) {
            float m = Math.abs(ev.getY() - downY);
            if (m > maxDy) {
                maxDy = m;
                updateDebug();                       // 实时显示最大位移，滑一次就能看出够不够阈值
            }
            return;
        }
        if (a != MotionEvent.ACTION_UP && a != MotionEvent.ACTION_CANCEL) return;

        upCount++;
        lastDy = ev.getY() - downY;
        updateDebug();

        if (dialogOverlay != null && dialogOverlay.getVisibility() == View.VISIBLE) return;
        if (swipeLocked) return;
        float dx = ev.getX() - downX;
        float dy = lastDy;
        if (Math.abs(dy) >= Math.abs(dx) * SWIPE_RATIO && Math.abs(dy) > dp(SWIPE_MIN_DP)) {
            swipeLocked = true;                                  // 一次手势只换一屏
            if (dy < 0f) showWindow(page + 1);                    // 手指向上滑 = 下一窗
            else         showWindow(page - 1);                    // 手指向下滑 = 上一窗
        }
    }

    // ------------------------------------------------------------------ 对话框

    void addDialogButton(String txt, View.OnClickListener l) {
        TextView t = mkText(txt, 14f);
        t.setPadding(dp(16), dp(9), dp(16), dp(9));
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
        lp.leftMargin = dp(5);
        lp.rightMargin = dp(5);
        dialogButtons.addView(t, lp);
    }

    void showAddDialog() {
        dialogTitle.setText("添加 API Key");
        dialogInput.setVisibility(View.VISIBLE);
        dialogInput.setText("");
        dialogInput.setHint("sk-...");
        dialogButtons.removeAllViews();
        addDialogButton("取消", new View.OnClickListener() {
            public void onClick(View v) {
                hideDialog();
            }
        });
        addDialogButton("确定", new View.OnClickListener() {
            public void onClick(View v) {
                String k = dialogInput.getText().toString().trim();
                hideDialog();
                if (k.length() == 0) return;
                store.add(k, null);
                selectedRow = store.currentIndex();
                rebuildKeyRows();
                updateAll();
                tempStatus("已添加 " + KeyStore.mask(k), HINT_ADD_MS);
            }
        });
        applyTheme();
        dialogOverlay.setVisibility(View.VISIBLE);
    }

    void showDeleteDialog(final int idx) {
        List<KeyStore.Entry> l = store.list();
        if (idx < 0 || idx >= l.size()) return;
        final String nm = l.get(idx).name;
        dialogTitle.setText("删除 " + nm + " ？");
        dialogInput.setVisibility(View.GONE);
        dialogButtons.removeAllViews();
        addDialogButton("取消", new View.OnClickListener() {
            public void onClick(View v) {
                hideDialog();
            }
        });
        addDialogButton("删除", new View.OnClickListener() {
            public void onClick(View v) {
                store.remove(idx);
                selectedRow = 0;
                hideDialog();
                rebuildKeyRows();
                updateAll();
                tempStatus("已删除 " + nm, HINT_LONG_MS);
            }
        });
        applyTheme();
        dialogOverlay.setVisibility(View.VISIBLE);
    }

    void hideDialog() {
        dialogOverlay.setVisibility(View.GONE);
        dialogInput.setText("");
    }

    // ------------------------------------------------------------------ Key 注入（免手表打字）

    /**
     * am start -n com.minis.dsbalance/.MainActivity -e apikey "sk-xxx" -e keyname "工作"
     * 只允许「追加并选中」，绝不覆盖/删除已有项。
     */
    void handleInject(Intent it) {
        if (it == null) return;
        String k = it.getStringExtra("apikey");
        if (k == null || k.trim().length() == 0) return;
        String n = it.getStringExtra("keyname");
        store.add(k, n);
        selectedRow = store.currentIndex();
        rebuildKeyRows();
        updateAll();
        tempStatus("已添加 " + KeyStore.mask(k.trim()), HINT_ADD_MS);
    }
}
