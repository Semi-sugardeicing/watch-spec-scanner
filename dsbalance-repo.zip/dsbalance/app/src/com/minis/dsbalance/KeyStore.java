package com.minis.dsbalance;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 多把 Key 的存储（SharedPreferences，MODE_PRIVATE）。
 * keys_json = [{"name":"sk-…3f9c","key":"sk-…","addedAt":1696000000000}, ...]
 * 绝不硬编码 Key；日志/界面只出现打码名。
 */
public class KeyStore {

    public static class Entry {
        public String name = "";
        public String key = "";
        public long addedAt = 0L;
    }

    private static final String SP_NAME = "balance";
    private static final String K_KEYS = "keys_json";
    private static final String K_CUR = "current_index";
    private static final String K_THEME = "theme_mode";
    private static final String K_PAGE = "page";
    private static final String K_LAST_MS = "last_refresh_ms";
    private static final String K_LAST_BAL = "last_balance";
    private static final String K_LAST_CUR = "last_currency";

    private final android.content.SharedPreferences sp;

    public KeyStore(android.content.Context c) {
        sp = c.getSharedPreferences(SP_NAME, android.content.Context.MODE_PRIVATE);
    }

    /** sk-abcdef1234 → sk-…1234 */
    public static String mask(String key) {
        if (key == null) return "";
        String k = key.trim();
        if (k.length() <= 7) return k.length() <= 2 ? "sk-…" : ("sk-…" + k.substring(k.length() - 2));
        return "sk-…" + k.substring(k.length() - 4);
    }

    public List<Entry> list() {
        List<Entry> out = new ArrayList<Entry>();
        String s = sp.getString(K_KEYS, "[]");
        try {
            JSONArray a = new JSONArray(s == null ? "[]" : s);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                Entry e = new Entry();
                e.name = o.optString("name", "");
                e.key = o.optString("key", "");
                e.addedAt = o.optLong("addedAt", 0L);
                if (e.key != null && e.key.trim().length() > 0) {
                    if (e.name == null || e.name.trim().length() == 0) e.name = mask(e.key);
                    out.add(e);
                }
            }
        } catch (Exception ignore) {
        }
        return out;
    }

    private void save(List<Entry> l) {
        JSONArray a = new JSONArray();
        try {
            for (int i = 0; i < l.size(); i++) {
                Entry e = l.get(i);
                JSONObject o = new JSONObject();
                o.put("name", e.name);
                o.put("key", e.key);
                o.put("addedAt", e.addedAt);
                a.put(o);
            }
        } catch (Exception ignore) {
        }
        sp.edit().putString(K_KEYS, a.toString()).apply();
    }

    public int currentIndex() {
        int n = list().size();
        if (n == 0) return 0;
        int i = sp.getInt(K_CUR, 0);
        if (i < 0 || i >= n) i = 0;
        return i;
    }

    public Entry current() {
        List<Entry> l = list();
        if (l.isEmpty()) return null;
        int i = currentIndex();
        if (i < 0 || i >= l.size()) i = 0;
        return l.get(i);
    }

    public void setCurrent(int i) {
        int n = list().size();
        if (n == 0) return;
        if (i < 0 || i >= n) i = 0;
        sp.edit().putInt(K_CUR, i).apply();
    }

    /** 追加（绝不覆盖/删除已有项） */
    public void add(String key, String name) {
        if (key == null) return;
        String k = key.trim();
        if (k.length() == 0) return;
        List<Entry> l = list();
        Entry e = new Entry();
        e.key = k;
        e.name = (name == null || name.trim().length() == 0) ? mask(k) : name.trim();
        e.addedAt = System.currentTimeMillis();
        l.add(e);
        save(l);
        sp.edit().putInt(K_CUR, l.size() - 1).apply();
    }

    public void remove(int i) {
        List<Entry> l = list();
        if (i < 0 || i >= l.size()) return;
        int cur = currentIndex();
        l.remove(i);
        save(l);
        if (l.isEmpty()) {
            sp.edit().putInt(K_CUR, 0).apply();
        } else {
            if (cur > i) cur--;
            if (cur >= l.size()) cur = l.size() - 1;
            if (cur < 0) cur = 0;
            sp.edit().putInt(K_CUR, cur).apply();
        }
    }

    public String nameAt(int i) {
        List<Entry> l = list();
        if (i < 0 || i >= l.size()) return "";
        return l.get(i).name;
    }

    // ---- 主题 / 页面 ----
    public int themeMode()              { return sp.getInt(K_THEME, Theme.DARK); }
    public void setThemeMode(int m)     { sp.edit().putInt(K_THEME, m).apply(); }
    public int page()                   { return sp.getInt(K_PAGE, 0); }
    public void setPage(int p)          { sp.edit().putInt(K_PAGE, p).apply(); }

    // ---- 最后刷新（持久化） ----
    public long lastRefresh()           { return sp.getLong(K_LAST_MS, 0L); }
    public void setLastRefresh(long ms) { sp.edit().putLong(K_LAST_MS, ms).apply(); }
    public String lastBalance()         { return sp.getString(K_LAST_BAL, ""); }
    public String lastCurrency()        { return sp.getString(K_LAST_CUR, ""); }

    public void setLastResult(String bal, String cur) {
        sp.edit().putString(K_LAST_BAL, bal == null ? "" : bal)
                 .putString(K_LAST_CUR, cur == null ? "" : cur)
                 .putLong(K_LAST_MS, System.currentTimeMillis())
                 .apply();
    }
}
