package com.minis.dsbalance;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * DeepSeek 余额查询（JDK 原生 HttpURLConnection + Android 内置 org.json，零第三方）。
 * 只取 total_balance + currency + 可用性。
 */
public class BalanceApi {

    public interface Callback {
        void onOk(String balance, String currency);
        void onFail(String message);
    }

    private static final String URL_BALANCE = "https://api.deepseek.com/user/balance";

    private final java.util.concurrent.ExecutorService ex =
            java.util.concurrent.Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    public void query(final String key, final Callback cb) {
        ex.execute(new Runnable() {
            public void run() {
                String bal = null, cur = null, err = null;
                HttpURLConnection c = null;
                try {
                    URL u = new URL(URL_BALANCE);
                    c = (HttpURLConnection) u.openConnection();
                    c.setRequestMethod("GET");
                    c.setConnectTimeout(10000);
                    c.setReadTimeout(15000);
                    c.setUseCaches(false);
                    c.setRequestProperty("Authorization", "Bearer " + key);
                    c.setRequestProperty("Accept", "application/json");
                    int code = c.getResponseCode();
                    if (code == 200) {
                        String body = read(c.getInputStream());
                        JSONObject o = new JSONObject(body);
                        JSONArray arr = o.optJSONArray("balance_infos");
                        if (arr != null && arr.length() > 0) {
                            JSONObject b = arr.optJSONObject(0);
                            if (b != null) {
                                bal = b.optString("total_balance", "");
                                cur = b.optString("currency", "CNY");
                            }
                        }
                        if (bal == null || bal.trim().length() == 0) err = "返回格式异常";
                    } else if (code == 401 || code == 403) {
                        err = "Key 无效";
                    } else if (code >= 500) {
                        err = "服务端繁忙";
                    } else {
                        err = "请求失败 " + code;
                    }
                } catch (java.net.SocketTimeoutException e) {
                    err = "网络超时";
                } catch (java.io.IOException e) {
                    err = "网络超时";
                } catch (Exception e) {
                    err = "返回格式异常";
                } finally {
                    if (c != null) c.disconnect();
                }

                if (err == null && bal == null) err = "返回格式异常";
                final String fbal = bal, fcur = cur, ferr = err;
                main.post(new Runnable() {
                    public void run() {
                        if (ferr == null) cb.onOk(fbal, fcur);
                        else cb.onFail(ferr);
                    }
                });
            }
        });
    }

    public void shutdown() {
        try {
            ex.shutdownNow();
        } catch (Exception ignore) {
        }
    }

    private static String read(InputStream in) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close();
        return sb.toString();
    }
}
