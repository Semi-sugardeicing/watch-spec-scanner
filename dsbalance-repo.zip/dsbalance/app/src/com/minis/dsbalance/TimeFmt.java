package com.minis.dsbalance;

import java.util.Calendar;

/** 时间戳 → 「15:42」/「10-01 15:42」（超过当天带日期） */
public class TimeFmt {

    public static String hhmm(long ms) {
        if (ms <= 0L) return "";
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ms);
        Calendar n = Calendar.getInstance();
        boolean sameDay = c.get(Calendar.YEAR) == n.get(Calendar.YEAR)
                && c.get(Calendar.DAY_OF_YEAR) == n.get(Calendar.DAY_OF_YEAR);
        String t = pad(c.get(Calendar.HOUR_OF_DAY)) + ":" + pad(c.get(Calendar.MINUTE));
        if (sameDay) return t;
        return pad(c.get(Calendar.MONTH) + 1) + "-" + pad(c.get(Calendar.DAY_OF_MONTH)) + " " + t;
    }

    private static String pad(int v) {
        return v < 10 ? ("0" + v) : ("" + v);
    }
}
