#!/bin/sh
# DeepSeek 余额手表 App —— 无 Gradle 构建：javac → d8 → APKEditor → apksigner
#
# 用法:
#   SDK=/opt/android-sdk sh app/scripts/build.sh [输出.apk]
#
# 可覆盖的环境变量:
#   SDK     Android SDK 根目录                     （默认 $HOME/android-sdk）
#   BT      build-tools 目录，需含 d8 与 apksigner  （默认 $SDK/android-15）
#   AJ      编译用 android.jar                     （默认 $SDK/android-11/android.jar）
#   AJP     APKEditor.jar                          （默认 $SDK/APKEditor.jar）
#   KS      签名密钥库（缺省会自动生成一个调试用）   （默认 $PROJ/build/debug.keystore）
#   KSPASS  密钥库口令                              （默认 android）
#   KALIAS  密钥别名                                （默认 dsbalance）
#
# 产物默认: app/dist/dsbalance.apk
set -e

PROJ=$(cd "$(dirname "$0")/.." && pwd)
SRC=$PROJ/src
TPL=$PROJ/template
OUT=${1:-$PROJ/dist/dsbalance.apk}
W=$PROJ/build

SDK=${SDK:-$HOME/android-sdk}
BT=${BT:-$SDK/android-15}
AJ=${AJ:-$SDK/android-11/android.jar}
AJP=${AJP:-$SDK/APKEditor.jar}
KS=${KS:-$PROJ/build/debug.keystore}
KSPASS=${KSPASS:-android}
KALIAS=${KALIAS:-dsbalance}

[ -f "$AJ" ]  || { echo "缺少 android.jar：$AJ"; exit 1; }
[ -f "$AJP" ] || { echo "缺少 APKEditor.jar：$AJP  → https://github.com/REAndroid/APKEditor/releases"; exit 1; }
command -v javac >/dev/null || { echo "缺少 javac（JDK 8+）"; exit 1; }

rm -rf "$W"
mkdir -p "$W/classes" "$W/dex" "$W/pack" "$(dirname "$OUT")"

find "$SRC" -name '*.java' > "$W/srcs.txt"
echo "[1/4] javac：$(wc -l < "$W/srcs.txt") 个 Java 文件"
javac -encoding UTF-8 -nowarn -source 8 -target 8 -bootclasspath "$AJ" -cp "$AJ" \
      -d "$W/classes" @"$W/srcs.txt"

echo "[2/4] d8 → dex"
find "$W/classes" -name '*.class' > "$W/classes.txt"
"$BT/d8" --lib "$AJ" --min-api 30 --output "$W/dex" @"$W/classes.txt"
[ -f "$W/dex/classes.dex" ] || { echo "  dex 生成失败"; exit 1; }

echo "[3/4] APKEditor 打包（含包名三处同步自检）"
cp -r "$TPL/." "$W/pack/"
M=$(grep -c 'package="com.minis.dsbalance"' "$W/pack/AndroidManifest.xml" || true)
P=$(grep -c '"package_name": "com.minis.dsbalance"' "$W/pack/resources/package_1/package.json" || true)
X=$(grep -c 'package="com.minis.dsbalance"' "$W/pack/resources/package_1/res/values/public.xml" || true)
echo "  包名同步 manifest=$M package.json=$P public.xml=$X"
if [ "$M" != "1" ] || [ "$P" != "1" ] || [ "$X" != "1" ]; then
  echo "  ✘ 包名三处不同步，停止构建"; exit 1
fi
mkdir -p "$W/pack/root"
cp "$W/dex/classes.dex" "$W/pack/root/classes.dex"
java -jar "$AJP" b -i "$W/pack" -o "$W/unsigned.apk"
[ -f "$W/unsigned.apk" ] || { echo "  打包失败"; exit 1; }

echo "[4/4] 签名"
if [ ! -f "$KS" ]; then
  echo "  没有密钥库，生成调试用签名：$KS"
  keytool -genkeypair -keystore "$KS" -alias "$KALIAS" -keyalg RSA -keysize 2048 \
          -validity 10000 -storepass "$KSPASS" -keypass "$KSPASS" \
          -dname "CN=dsbalance, O=dsbalance, C=CN"
fi
"$BT/apksigner" sign --ks "$KS" --ks-key-alias "$KALIAS" \
    --ks-pass "pass:$KSPASS" --key-pass "pass:$KSPASS" --out "$OUT" "$W/unsigned.apk"
"$BT/apksigner" verify --print-certs "$OUT" | head -4
echo "完成 -> $OUT ($(wc -c < "$OUT") 字节)"
