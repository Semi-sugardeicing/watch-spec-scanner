# DeepSeek 余额 · 手表版

[![minSdk](https://img.shields.io/badge/minSdk-30-3ddc84)](#)
[![依赖](https://img.shields.io/badge/依赖-零第三方-4ecda4)](#)
[![权限](https://img.shields.io/badge/权限-仅%20INTERNET-blue)](#)

一个给 **圆屏 Android 手表** 用的极简 App：抬手看一眼 DeepSeek API 还剩多少钱。

为 OPPO Watch X2（466×466 圆屏 / Android 11 / 320dpi）写的，但代码里所有尺寸都是 dp，
换一台圆屏表改两个常量即可（见 [`docs/round-screen-notes.md`](docs/round-screen-notes.md)）。

## 预览

> 按源码坐标常量渲染的布局示意（不是实机截图）。三窗均居中，屏幕上永远只有一屏（原地换页，不滑动）：

![三窗布局](docs/preview.png)

## 设计取舍

**一窗一件事，共 3 个窗口**；翻窗有三条通道 —— 屏幕底部常驻的 **「▼ 下一屏」按钮**（点一下就翻，
唯一不依赖手势/传感器的通道，到第 3 窗变成「▼ 回第 1 窗」）、手指上下滑、表冠旋转（都到头停住、不循环）：

| 窗口 | 内容 |
|---|---|
| 窗 1 · 余额 | 大号金额 + 状态行 |
| 窗 2 · 刷新 | 状态行 + 大圆钮「刷新」+ 按钮下方就地状态文字（`刷新中…` / 错误原因） |
| 窗 3 · Key 管理 | Key 列表（点=切换、长按=删除）+ 底部「添加」 |

- **只有窗 2 那颗按钮会发请求**。冷启动、`onResume`、抬腕、翻窗、切主题、切 Key —— 一律不联网。
- 界面上**永远不出现 Key 明文**，只显示 `sk-…1234`。
- 暗色 / 亮色双主题，**从右往左滑**切换（从左往右忽略，避开系统返回手势）。
- 表冠到头停住，不循环；表冠按压不处理（交给系统退出）。
- **翻窗不依赖表冠**：手指上下滑、底部「▼ 下一屏」按钮都是同一条通道，表冠坏了 App 照样能用。
- **三条通道都在真机（OPPO Watch X2）上实测过** —— 按钮 / 手指上·下滑 / 表冠旋转，翻窗都正常。
- 没有设置页、没有统计、没有后台服务、没有网络权限以外的任何权限。

## 安装

下载 [`dist/dsbalance.apk`](dist/dsbalance.apk) → 传到手表安装（`adb install` 或手表端文件管理器）。

签名是自签的（`CN=Minis`），装之前需要在手表上允许「安装未知来源应用」。

## 添加 API Key

DeepSeek 的 Key 在 <https://platform.deepseek.com/api_keys> 申请。

**方式一（推荐，免在手表上打字）：**

```sh
adb shell am start -n com.minis.dsbalance/.MainActivity -e apikey "sk-xxxx" -e keyname "工作"
```

只追加、不覆盖已有项，追加后自动选中。

**方式二：** 窗 3 底部「添加」→ 手表上输入。

支持多把 Key：窗 3 点一下切换当前 Key，长按删除。

## 交互

| 操作 | 结果 |
|---|---|
| 点窗 2 的圆钮 | 查询余额；成功后自动翻回窗 1 |
| **点底部的「▼ 下一屏」** | 下一窗（第 3 窗时是「▼ 回第 1 窗」）—— 换页主轴，不依赖任何手势/传感器 |
| **手指上滑 / 下滑** | 下一窗 / 上一窗（\|dy\| ≥ \|dx\| 且 >28dp 才算，一次手势只换一屏） |
| **旋转表冠** | 顺/逆翻窗；窗 3 里上下移动高亮项 |
| **从右往左滑** | 暗色 ↔ 亮色 |
| 窗 3 点列表项 | 切换当前 Key（不自动刷新） |
| 窗 3 长按列表项 | 删除确认 |

> 屏幕顶部还有一行常驻小字 `P2  v4·1.1` / `D3 U3 dy-45 m-56`：前者是当前窗号 + 版本号，
> 后者是触摸自证（DOWN/UP 次数、末次手势纵向位移、本次手势最大位移）。调版式/查触摸时很有用，不需要可以删掉。

## 节流刹车

三个数字集中在 `Throttle.java` 文件头，想改很方便：

- 请求飞行中：重复点击不发、不排队
- 距上次真实请求 < 3 秒：中央提示「过于频繁 / 请稍后尝试」1.5 秒
- 10 秒内 ≥ 4 次真实请求：进入**固定 10 秒**惩罚期，中央倒计时；期间点击**不延长**惩罚

## 状态行文案

`点击刷新` · `刷新中…`（只在窗 2 按钮下方）· `最后刷新 15:42` · `未设置 Key` · 跨天自动带日期 `最后刷新 10-01 15:42`

失败时状态行仍显示上次成功时间，错误原因写在按钮下方（`网络超时` / `Key 无效` / `请求失败 4xx`）。

## 构建

无 Gradle、无 Android Studio、**零第三方依赖**（只用 `HttpURLConnection` + `org.json`），
`javac → d8 → APKEditor → apksigner` 一条命令出包。详见 [`docs/BUILD.md`](docs/BUILD.md)。

```sh
SDK=/path/to/android-sdk sh app/scripts/build.sh    # 产物 app/dist/dsbalance.apk
```

UI 全部用 Java 手写视图搭出来，**没有改动任何 `res/` 资源**，所以不需要 `aapt2` 重新编资源。

## 能力边界（官方 API 决定的，不是偷懒）

DeepSeek 只开放了 `GET /user/balance` 一个查询接口，所以这个 App **只能显示余额**：
看不到用量、消费明细、请求数、Token 统计、趋势图 —— 那些官方不开放。

## 隐私

- Key 只存在本机 `SharedPreferences`（`MODE_PRIVATE`），不上传任何第三方。
- 全 App 只向 `https://api.deepseek.com/user/balance` 发一个 `GET`，带 `Authorization: Bearer <key>`。
- 没有统计、没有崩溃上报、没有广告。

## License

[MIT](LICENSE)

---

### English

A tiny DeepSeek API balance viewer for round-screen Android watches (built for OPPO Watch X2,
466×466 / Android 11). Three crown-swiped screens — balance, refresh, key management — with
manual-only refresh, dark/light themes and zero third-party dependencies. The whole UI is built
in Java at runtime, so there are no XML layout resources to compile. See `docs/BUILD.md` for the
Gradle-free build.
