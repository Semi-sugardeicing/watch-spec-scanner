# 圆屏手表适配笔记（实测）

目标机：某款 466×466 圆屏 Wear 类手表（Android 11 / API 30 / 320dpi / arm64-v8a）。
下面每条都来自**这台机器上的实机测量**，换表请重新测一遍，但结论的"形状"大概率通用。

## 1. 屏幕常量

| 常量 | 值 | 用途 |
|---|---|---|
| 屏幕像素 | `466 × 466 px` | 画布基准 |
| densityDpi | `320` | — |
| density | `2.0f` | px ÷ 2 = dp，即 1dp = 1sp = 2px |
| 屏幕尺寸 | `233 × 233 dp` | 布局上限 |
| **内接正方形** | `466 / √2 = 329.5 px = 164.7 dp` | 内容必须落在里面 |
| **四边留白** | `34 dp` | `(233 − 164.7) / 2 ≈ 34.15` |
| `isScreenRound` | `true` | — |
| **systemBars / cutout 内缩** | **四边全 0** | 不需要为系统栏留 padding |

**这个 0 是关键坑**：圆角裁切**不进 WindowInsets**，读 insets 得到的全是 0，
所以不要指望靠 insets 保平安 —— 一律按 164.7dp 的内接正方形摆内容。

**更严一点的经验值**：标尺实测 36 个方向的最外侧可视半径 = 229~231px，非常一致，
说明**整块 466×466 都能画、没有额外裁切**；但内接正方形的四个顶点（半径 233px）正好压在可视边界上。
所以：

- 「绝对不许越界」的硬上限 = 164.7dp 内接正方形
- **关键文字 / 按钮的实际落点 = 半径 ≤ 200px（= 100dp）的圆内**，别去够四个角
- 画笔画时：外沿留在半径 ≤ 225px 以内（233 − 描边与抗锯齿余量）

沉浸式（`IMMERSIVE_STICKY` 会把 insets 读数抹成 0，调试时别用）：

```java
getWindow().getDecorView().setSystemUiVisibility(
        View.SYSTEM_UI_FLAG_LAYOUT_STABLE
      | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
      | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
```

## 2. 触摸

单击 / 长按 / 双击 / 拖动 —— **4/4 全部正常**。

- 单击与双击共存时用 `GestureDetector`，注意 `onSingleTapConfirmed` 有约 300ms 确认延迟。
- 可拖动的自定义 View 记得 `getParent().requestDisallowInterceptTouchEvent(true)`，
  否则拖动会被外层可滚动容器吃成滚动。

## 3. 表冠（旋转）

| 项 | 实测结果 |
|---|---|
| `InputDevice` 里能不能枚举到 `SOURCE_ROTARY_ENCODER` | **不能**（但这**不代表表冠不可用**） |
| `ACTION_SCROLL` | **收得到**，累计 delta 稳定（实测 -1694.7） |
| 事件源 `src` | **`0x2002` = `SOURCE_MOUSE`**（被系统当鼠标滚轮类设备上报） |

实现放在 **Activity** 上（不是普通 View）：

```java
@Override
public boolean dispatchGenericMotionEvent(MotionEvent ev) {
    if (ev != null && ev.getAction() == MotionEvent.ACTION_SCROLL) {
        float a = ev.getAxisValue(MotionEvent.AXIS_SCROLL);
        float v = ev.getAxisValue(MotionEvent.AXIS_VSCROLL);
        float d = (a != 0f) ? a : v;                 // 两条轴都取一下，谁有值用谁
        crownAccum += d;                              // d 的符号 = 方向
        if (crownAccum <= -2.0f) { crownAccum = 0; onCrown(-1); }
        else if (crownAccum >= 2.0f) { crownAccum = 0; onCrown(+1); }
    }
    return super.dispatchGenericMotionEvent(ev);
}
```

### 三条禁令（都是踩过的坑）

1. **别用 `SOURCE_ROTARY_ENCODER` 判断表冠是否存在** —— 本机枚举不到，会白白放弃一个可用功能。
2. **别按 `ev.getSource() == SOURCE_ROTARY_ENCODER` 过滤事件** —— 事件源是 `SOURCE_MOUSE`，一过滤就全丢。
3. **别 `return true` 吞掉 `ACTION_SCROLL`** —— 依赖滚动的容器会跟着失效（本 App 全屏自绘、翻页自己驱动，才敢返回 `true`）。

### 单步步进

实测只记录了**累计值**，单格增量没单独记。所以实现上按**累计阈值（±2.0）**触发，
既避开抖动，也不依赖未知的单格步进 —— 换表以后这个阈值可能要重调，但机制不用改。

## 4. 物理按键

表冠**按压** = `keyCode 131 (KEYCODE_F1)`，源 `src = 0x101 (SOURCE_KEYBOARD)`，
在 `Activity.onKeyDown` 里就能拿到。

本 App 故意**不处理**它：这颗键默认会被系统当成返回/退出，处理它反而容易和系统行为打架，
而且 App 里没有任何未保存状态，退出就退出。

## 5. 新 App 开工自检清单

- [ ] 布局按 34dp 四边留白，内容在 164.7dp 内接正方形内（关键内容再收进 100dp 半径圆）
- [ ] 没有为 systemBars / cutout 预留 padding（实测就是 0）
- [ ] 表冠接了 `dispatchGenericMotionEvent` + `ACTION_SCROLL`
- [ ] 没有任何地方用 `SOURCE_ROTARY_ENCODER` 做判断或过滤
- [ ] 核心操作不依赖表冠（表冠只当附加通道，触摸也能完成）
