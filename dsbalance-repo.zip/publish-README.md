# publish/ —— 两个手表 App 的开源发布副本

更新：2026-10-02

这两个目录是**已经脱敏、可以公开**的独立仓库（各自带 `.git`、已提交到 `main`），
源工程在 `/var/minis/shared/watch_app/`（内部版，含实机记录/计划/错误日志，**不要公开**）。

| 目录 | 对应仓库 | 产物 | 状态 |
|---|---|---|---|
| `dsbalance/` | DeepSeek 余额 · 手表版 | `dist/dsbalance.apk` 33820 B · CN=Minis · SHA `49c538fa…6f9607` · v4/1.1 | ✅ 可发布 |
| `watch-probe/` | 手表探针 | `dist/watch-probe.apk` 58306 B · CN=Watch Probe · SHA `e1f8c1ca…2f03` | ✅ 可发布 |

两个仓库都是 **MIT**、零第三方依赖、无 Gradle（`javac → d8 → APKEditor → apksigner`）。

## 怎么发布（一条命令）

```sh
export GITHUB_TOKEN=xxx            # 或在 Settings → 环境变量 里设 GITHUB_TOKEN
cd /var/minis/shared/publish
python3 publish_to_github.py watch-probe            # 建 <你的用户名>/watch-probe 并推 main
python3 publish_to_github.py dsbalance              # 同理
python3 publish_to_github.py watch-probe --private  # 私有仓库
python3 publish_to_github.py watch-probe --dry-run  # 只列文件、不联网
```

为什么不用 `git push`：**本机到 `github.com` 的连接会超时**（`api.github.com` 正常）。
所以脚本走 REST API 的 blobs → trees → commits → refs，完全不依赖 git 传输层。

## 每次改完内容要做什么

```sh
cd <repo> && git add -A && git commit -m "..."   # 提交到本地
git archive --format=zip --prefix=<name>/ -o /var/minis/attachments/<name>-repo.zip HEAD
python3 ../publish_to_github.py <name>            # 再推一次（脚本会对已存在的 main 追加提交）
```

## 脱敏规矩（新文件入库前必查）

```sh
grep -rniE 'minis|/var/|OWW251|OPPO' <repo> | grep -v '\.git/'
```

- 去掉设备指纹（机型/版本号）、所有 `/var/minis/...` 内部路径、内部 PLAN / ERROR_LOG、探针工程
- 模板里的二进制残留（`.cache/classes.dex`、`root/classes.dex`）不入库（实测去掉后 `APKEditor b` 照样出包）
- 产物签名：`watch-probe` 用仓库内自签密钥（密码公开，方便别人 clone 完直接出包）；
  `dsbalance` 用作者自用密钥，**不随仓库分发** → 自建包签名不同，不能覆盖安装（已写进它的 `docs/BUILD.md`）

## 已验证

- `publish_to_github.py --dry-run` 的文件清单与两个仓库的 `git ls-files` **逐条一致**（33 / 26 个文件）
- 两个仓库的 `app/scripts/build.sh` 都能用本机 SDK 一条命令出包（dsbalance 实测产出 33826 B 签名 APK）
- 匿名 `GET https://api.github.com/repos/REAndroid/APKEditor` → 200（链路通，只差 token）
